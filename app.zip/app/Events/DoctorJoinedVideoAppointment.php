<?php

namespace App\Events;

use App\Models\AppointmentModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class DoctorJoinedVideoAppointment implements ShouldBroadcast
{
    use Dispatchable, SerializesModels;

    public int $appointment_id;
    public ?string $meeting_id;
    public ?string $meeting_link;
    public ?string $video_provider;
    public ?string $doctor_joined_at;

    public function __construct(AppointmentModel $appointment)
    {
        $this->appointment_id = (int) $appointment->id;
        $this->meeting_id = $appointment->meeting_id ? (string) $appointment->meeting_id : null;
        $this->meeting_link = $appointment->meeting_link ? (string) $appointment->meeting_link : null;
        $this->video_provider = $appointment->video_provider ? (string) $appointment->video_provider : null;
        $this->doctor_joined_at = $appointment->doctor_joined_at
            ? $appointment->doctor_joined_at->toDateTimeString()
            : null;
    }

    public function broadcastOn(): array
    {
        return [
            new Channel('appointment-video.' . $this->appointment_id),
        ];
    }

    public function broadcastAs(): string
    {
        return 'doctor.joined';
    }

    public function broadcastWith(): array
    {
        return [
            'appointment_id' => $this->appointment_id,
            'meeting_id' => $this->meeting_id,
            'meeting_link' => $this->meeting_link,
            'video_provider' => $this->video_provider,
            'doctor_joined_at' => !empty($appointment->doctor_joined_at)
            ? (
                is_string($appointment->doctor_joined_at)
                    ? $appointment->doctor_joined_at
                    : \Carbon\Carbon::parse($appointment->doctor_joined_at)->toDateTimeString()
            )
            : null,
        ];
    }
}